package edu.washington.cs.grail.relative_size.nlp.search.models;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchResult {
	private String link;
	private String title;
	private String snippet;

	public SearchResult(String link, String title, String snippet) {
		this.link = link;
		this.title = title;
		this.snippet = snippet;
	}

	public SearchResult(String title, String snippet) {
		this(null, title, snippet);
	}

	public String getUrl() {
		return link;
	}

	public String getTitle() {
		return title;
	}

	public String getSnippet() {
		return snippet;
	}

	public List<String> getMatches(String query) {
		List<String> matches = new ArrayList<String>();

		query = query.replaceAll("\\*", ".*?");
		Pattern pattern = Pattern.compile(query, Pattern.CASE_INSENSITIVE);
		
		Matcher matcher = pattern.matcher(title);
		while (matcher.find()) {
			matches.add(matcher.group());
		}
		
		matcher = pattern.matcher(snippet);
		while (matcher.find()) {
			matches.add(matcher.group());
		}
		return matches;
	}
}
