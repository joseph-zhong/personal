package edu.washington.cs.grail.relative_size.graph.models;

public class Observation implements Comparable<Observation> {
	private double value, score;
	
	public Observation(double value, double score) {
		this.value = value;
		this.score = score;
	}

	public double getValue() {
		return value;
	}
	
	public double getScore() {
		return score;
	}
	
	public int compareTo(Observation o) {
		return (int)Math.signum(value - o.value);
	}
}
