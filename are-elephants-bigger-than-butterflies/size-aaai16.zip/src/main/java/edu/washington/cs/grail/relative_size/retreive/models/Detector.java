package edu.washington.cs.grail.relative_size.retreive.models;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Logger;

import edu.washington.cs.grail.relative_size.utils.Downloader;

public class Detector {
	private static final String MODELS_DIRECTORY = "data/models/ngrams";
	private static final Logger LOG = Logger.getLogger(Detector.class.getName());
	
	static {
		File modelsDirectory = new File(MODELS_DIRECTORY);
		if (!modelsDirectory.exists())
			modelsDirectory.mkdir();
	}

	private String object;
	private String filePath;
	
	public Detector(URL url, String object) {
		this.object = object;
		
		File filePath = new File(getModelDirectory() + object + ".mat");
		this.filePath = filePath.getAbsolutePath();
		if (!filePath.exists())
			try {
				Downloader.download(url, filePath.getPath());
			} catch (IOException e) {
				LOG.severe("Failed to write the model for " + object);
			}
	}
	
	public String getFilePath() {
		return filePath;
	}
	
	public String getObject() {
		return object;
	}

	private String getModelDirectory() {
		return MODELS_DIRECTORY + "/";
	}

}
