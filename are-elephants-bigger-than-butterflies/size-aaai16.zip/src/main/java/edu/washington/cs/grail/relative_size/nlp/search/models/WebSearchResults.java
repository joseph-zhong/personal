package edu.washington.cs.grail.relative_size.nlp.search.models;


public interface WebSearchResults {
	Long getNumResults();
	SearchResult[] getTopResults();
}
