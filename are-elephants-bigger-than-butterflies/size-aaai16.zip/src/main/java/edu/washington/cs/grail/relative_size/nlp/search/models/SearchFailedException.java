package edu.washington.cs.grail.relative_size.nlp.search.models;

public class SearchFailedException extends Exception {
	private static final long serialVersionUID = -4626286362735322206L;
	
	public SearchFailedException() {
		super("Search failed.");
	}
	
	public SearchFailedException(String message) {
		super(message);
	}
	
}
