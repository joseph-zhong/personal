package edu.washington.cs.grail.relative_size.nlp.search.models;

public class GoogleSearchResponse implements WebSearchResults{
	private static class SearchInformation{
		private long totalResults;
	}
	
	
	private SearchInformation searchInformation;
	private SearchResult[] items;

	public Long getNumResults(){
		if (searchInformation == null)
			return null;
		else
			return searchInformation.totalResults;
	}
	
	public SearchResult[] getTopResults(){
		if (items == null)
			return new SearchResult[]{};
		else
			return items;
	}
}
