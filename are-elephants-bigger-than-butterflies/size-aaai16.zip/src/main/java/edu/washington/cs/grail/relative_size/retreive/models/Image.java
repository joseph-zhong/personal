package edu.washington.cs.grail.relative_size.retreive.models;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.UUID;

import edu.washington.cs.grail.relative_size.utils.Downloader;

public class Image {
	private static final String IMAGES_DIRECTORY = "data/images";

	static {
		File imagesDirectory = new File(IMAGES_DIRECTORY);
		if (!imagesDirectory.exists())
			imagesDirectory.mkdir();
	}

	private String firstObject, secondObject;
	private String filePath;

	public Image(String firstObject, String secondObject) {
		setObjects(firstObject, secondObject);
	}

	public Image(URL url, String firstObject, String secondObject) throws IOException {
		setObjects(firstObject, secondObject);
		this.filePath = new File(getImageDirectory()
				+ UUID.randomUUID().toString() + ".jpg").getAbsolutePath();
		
		Downloader.download(url, this.filePath);
	}
	
	public ArrayList<Image> getAllImages(){
		if (filePath != null)
			throw new RuntimeException("Already assigned to a file.");
		
		ArrayList<Image> result = new ArrayList<Image>();
		File directory = new File( getImageDirectory() );
		for (File filePath: directory.listFiles(new ImageFileFilter())){
			Image current = new Image(firstObject, secondObject);
			current.filePath = filePath.getAbsolutePath();
			result.add(current);
		}
		return result;
	}
	
	public int getImagesAvailable(){
		if (filePath != null)
			throw new RuntimeException("Already assigned to a file.");
		
		File directory = new File( getImageDirectory() );
		return directory.listFiles(new ImageFileFilter()).length;
	}
	
	public String getFilePath() {
		return filePath;
	}

	public String getFirstObject() {
		return firstObject;
	}

	public String getSecondObject() {
		return secondObject;
	}

	private void setObjects(String firstObject, String secondObject) {
		if (firstObject.compareTo(secondObject) < 0) {
			String tmp = firstObject;
			firstObject = secondObject;
			secondObject = tmp;
		}

		this.firstObject = firstObject;
		this.secondObject = secondObject;
	}

	private String getImageDirectory() {
		String path = IMAGES_DIRECTORY + "/" + this.firstObject + "-"
				+ this.secondObject + "/";
		File file = new File(path);
		if (!file.exists())
			file.mkdir();
		return path;
	}
	
	private class ImageFileFilter implements FilenameFilter{
		private final String[] compatibleExtensions = 
			    {"jpg", "png", "gif"};
		
		public boolean accept(File dir, String name) {
			name = name.toLowerCase();
			for(String extension: compatibleExtensions)
				if (name.endsWith(extension))
					return true;
			return false;
		}
	}

}
