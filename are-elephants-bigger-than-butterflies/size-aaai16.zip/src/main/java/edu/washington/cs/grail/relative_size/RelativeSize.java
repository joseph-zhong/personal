package edu.washington.cs.grail.relative_size;

import java.io.IOException;

import edu.washington.cs.grail.relative_size.graph.LoadAndTestObjectsNetwork;


public class RelativeSize 
{
	
	public static void main(String[] args) throws IOException {
		LoadAndTestObjectsNetwork.main(args);
	}
}

