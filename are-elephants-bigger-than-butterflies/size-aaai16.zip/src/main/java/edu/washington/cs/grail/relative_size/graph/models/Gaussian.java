package edu.washington.cs.grail.relative_size.graph.models;

import java.io.Serializable;

import org.apache.commons.math3.distribution.NormalDistribution;

public class Gaussian implements Serializable {
	private static final long serialVersionUID = 8600245823257880448L;

	private double mean, variance;

	public Gaussian() {
//		Random random = new Random();
		this.mean = 0; // random.nextGaussian()*10;
		this.variance = 1;
	}
	
	public Gaussian(double mean, double variance){
		this.mean = mean;
		this.variance = variance;
	}

	public double getMean() {
		return mean;
	}

	public double getVariance() {
		return variance;
	}

	public void setMean(double mean) {
		this.mean = mean;
	}

	public void setVariance(double variance) {
		this.variance = variance;
	}
	
	public Gaussian clone(){
		return new Gaussian(mean, variance);
	}

	@Override
	public String toString() {
		return "N(" + mean + ", " + variance + ")";
	}

	public static Gaussian average(Gaussian ... gaussians) {
		double avgMean = 0;
		double avgVar = 0;
		double meanDenom = 0;
		double varDenom = 0;
		
		for (Gaussian g : gaussians){
			double weight = 1.0 / g.getVariance();
			avgMean += weight*g.getMean();
			avgVar += weight*weight*g.getVariance();
			
			meanDenom += weight;
			varDenom += weight * weight;
		}
		avgMean /= meanDenom;
		avgVar /= varDenom;
		
		return new Gaussian(avgMean, avgVar);
	}

	public Gaussian subtract(Gaussian second) {
		return new Gaussian(mean-second.mean, variance + second.variance);
	}

	public double getNonZeroProbability() {
		NormalDistribution normal = new NormalDistribution(mean, Math.sqrt(variance));
		return 1 - normal.cumulativeProbability(0);
	}
}
