package edu.washington.cs.grail.relative_size.tags;

import edu.washington.cs.grail.relative_size.tags.models.TagUrl;

public interface TagUrlReader {
	public TagUrl nextTagUrl();
}
