package edu.washington.cs.grail.relative_size.tags.models;

public class TagUrl {
	private String[] tags;
	private String url;

	public TagUrl(String[] tags, String url) {
		this.tags = tags;
		this.url = url;
	}

	public String[] getTags() {
		return tags;
	}

	public String getUrl() {
		return url;
	}

	public void makeTagsNeat() {
		for (int i = 0; i < this.tags.length; i++)
			this.tags[i] = this.tags[i].replace('+', '_');
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for (int i=0 ; i<tags.length ; i++){
			if (i != 0)
				sb.append("\t");
			sb.append(tags[i]);
		}
		sb.append("\n");
		sb.append(url);
		
		return sb.toString();
	}
}
