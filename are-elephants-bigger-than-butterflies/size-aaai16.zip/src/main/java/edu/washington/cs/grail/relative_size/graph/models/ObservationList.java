package edu.washington.cs.grail.relative_size.graph.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Logger;

import edu.washington.cs.grail.relative_size.utils.Config;

public class ObservationList implements Serializable {
	private static final long serialVersionUID = 6076840261840777028L;

	private static double scoreThreshold = Config.getDoubleValue(
			"graph-detector-threshold", -0.9);
	private static double threshCoeff = Config.getDoubleValue(
			"graph-threshold-coefficient", 1);
	private static boolean useDepth = Config.getBooleanValue(
			"graph-incorporate-depth", false);

	private static final Logger LOG = Logger.getLogger(ObservationList.class
			.getName());

	private double thresh1, thresh2;
	private double[] logSizes, logDepths;
	private Double[] score1, score2;
	private Double averageLogSize = null;
	private Double varianceLogSize = null;
	private Integer validCount = 0;
	private Double updatedThreshold = null;
	private Double updatedCoeff = null;
	private Boolean usedDepth = null;
	private double observationScore;

	public static void setScoreThreshold(double threshold) {
		ObservationList.scoreThreshold = threshold;
	}

	public static double getScoreThreshold() {
		return scoreThreshold;
	}

	public static void setThresholdCoefficient(double threshCoeff) {
		ObservationList.threshCoeff = threshCoeff;
	}

	public static double getThreshCoefficient() {
		return threshCoeff;
	}

	public ObservationList(Double thresh1, Double thresh2, Double[] sizes,
			Double[] depths, Double[] score1, Double[] score2) {
		this.thresh1 = thresh1;
		this.thresh2 = thresh2;

		this.logSizes = new double[sizes.length];
		this.logDepths = new double[depths.length];
		for (int i = 0; i < sizes.length; i++) {
			if (sizes[i] == null || sizes[i] == 0) {
				LOG.severe("Trying to add observation zero which is non-sense. Abort.");
				this.logSizes = null;
				return;
			}

			this.logSizes[i] = Math.log(sizes[i]);
			this.logDepths[i] = Math.log(depths[i]);
		}
		this.score1 = score1;
		this.score2 = score2;
	}

	public ObservationList getReverse() {
		Double[] revLogSizes = new Double[logSizes.length];
		Double[] revLogDepths = new Double[logSizes.length];
		for (int i = 0; i < revLogSizes.length; i++) {
			revLogSizes[i] = Math.exp(-logSizes[i]);
			revLogDepths[i] = Math.exp(-logDepths[i]);
		}

		return new ObservationList(thresh2, thresh1, revLogSizes, revLogDepths,
				this.score2, this.score1);
	}

	public double getObservationScore() {
		refreshAverageLogSize();
		return observationScore;
	}

	public Observation[] getLogObservations() {
		ArrayList<Observation> res = new ArrayList<Observation>();
		for (int i = 0; i < logSizes.length; i++)
			if (score1[i] > Math.max(ObservationList.threshCoeff * thresh1,
					ObservationList.scoreThreshold)
					&& score2[i] > Math.max(ObservationList.threshCoeff
							* thresh2, ObservationList.scoreThreshold)) {
				if (useDepth) {
					res.add(new Observation(logSizes[i] + logDepths[i],
							getScore(score1[i], score2[i])));
				} else {
					res.add(new Observation(logSizes[i], getScore(score1[i],
							score2[i])));
				}
			}
		return res.toArray(new Observation[] {});
	}

	public Observation[] getObservations() {
		ArrayList<Observation> res = new ArrayList<Observation>();
		for (int i = 0; i < logSizes.length; i++)
			if (score1[i] > Math.max(ObservationList.threshCoeff * thresh1,
					ObservationList.scoreThreshold)
					&& score2[i] > Math.max(ObservationList.threshCoeff
							* thresh2, ObservationList.scoreThreshold)) {
				if (useDepth) {
					res.add(new Observation(Math
							.exp(logSizes[i] + logDepths[i]), getScore(
							score1[i], score2[i])));
				} else {
					res.add(new Observation(Math.exp(logSizes[i]), getScore(
							score1[i], score2[i])));
				}
			}
		return res.toArray(new Observation[] {});
	}

	public double getAverageSize() {
		Double averageLogSize = getAverageLogSize();
		if (averageLogSize == null)
			return 0;
		else
			return Math.exp(getAverageLogSize());
	}

	public Double getAverageLogSize() {
		refreshAverageLogSize();
		return this.averageLogSize;
	}

	public Double getVarianceLogSize() {
		refreshAverageLogSize();
		return varianceLogSize;
	}

	public boolean isValid() {
		return this.logSizes != null;
	}

	public int getCount() {
		refreshAverageLogSize();
		return validCount;
	}

	public boolean isThresholdUpdated() {
		return (updatedThreshold == null || updatedThreshold != ObservationList.scoreThreshold)
				|| (updatedCoeff == null || updatedCoeff != ObservationList.threshCoeff)
				|| (usedDepth == null || usedDepth != ObservationList.useDepth);
	}

	private double getScore(Double score1, Double score2) {
		return 1;//Math.exp(score1 + score2);
	}

	private void refreshAverageLogSize() {
		if (!isThresholdUpdated())
			return;

		updatedCoeff = ObservationList.threshCoeff;
		updatedThreshold = ObservationList.scoreThreshold;
		usedDepth = ObservationList.useDepth;

		this.validCount = 0;
		ArrayList<Observation> validLogSizes = new ArrayList<Observation>();
		ArrayList<Double> weights = new ArrayList<Double>();

		for (int i = 0; i < logSizes.length; i++)
			if (score1[i] > Math.max(ObservationList.threshCoeff * thresh1,
					ObservationList.scoreThreshold)
					&& score2[i] > Math.max(ObservationList.threshCoeff
							* thresh2, ObservationList.scoreThreshold)) {

				double value = logSizes[i];
				if (useDepth)
					value -= logDepths[i];
				double score = getScore(score1[i], score2[i]);

				validLogSizes.add(new Observation(value, score));
				weights.add(score);
				this.validCount++;
			}

		Collections.sort(validLogSizes);

		final int ignore = this.validCount / 5;
		this.validCount -= 2 * ignore;
		if (this.validCount < 0)
			this.validCount = 0;

		double avg = 0;
		double denom = 0;
		for (int i = ignore; i < validLogSizes.size() - ignore; i++) {
			avg += validLogSizes.get(i).getScore()
					* validLogSizes.get(i).getValue();
			denom += validLogSizes.get(i).getScore();
		}

		avg /= denom;
		double var = 0;
		for (int i = ignore; i < validLogSizes.size() - ignore; i++) {
			var += validLogSizes.get(i).getScore()
					* (validLogSizes.get(i).getValue() - avg)
					* (validLogSizes.get(i).getValue() - avg);
		}
		var /= denom;

		if (this.validCount == 0) {
			this.averageLogSize = null;
			this.varianceLogSize = null;
			this.observationScore = 0;
		} else {
			this.averageLogSize = avg;
			this.varianceLogSize = var;
			this.observationScore = denom;
		}
	}
}
