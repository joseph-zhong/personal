package edu.washington.cs.grail.relative_size.scheduler;

public enum JobStatus {
	NOT_SUBMITTED,
	SUBMIT_FAILED,
	WAITING_QUEUE,
	RUNNING,
	DONE
}
